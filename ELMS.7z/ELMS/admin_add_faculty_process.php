
<?php

$emp_id = $_POST['emp_id'];
$emp_password = $_POST['emp_password'];
$emp_name = $_POST['emp_name'];
$emp_dept = $_POST['emp_dept'];
$emp_DOJ = $_POST['emp_DOJ'];
$emp_design = $_POST['emp_design'];
$emp_mobile_no = $_POST['emp_mobile_no'];
$emp_email = $_POST['emp_email'];
$emp_DOB = $_POST['emp_DOB'];
$emp_BG = $_POST['emp_BG'];
$admin_id = $_SESSION["admin_id"];	


$conn = mysqli_connect('localhost', 'root', '', 'ELMS');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO faculty (emp_id, emp_password ,emp_name, emp_dept, emp_DOJ, emp_design, emp_mobile_no, emp_email, emp_DOB, emp_BG) VALUES ('$emp_id','$emp_password', '$emp_name', '$emp_dept', '$emp_DOJ', '$emp_design', '$emp_mobile_no', '$emp_email', '$emp_DOB', '$emp_BG')";

if (mysqli_query($conn, $sql)) {
 echo "New record created successfully";
	header('Location:admin_add_confirm.php');
	
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}


mysqli_close($conn);

?>
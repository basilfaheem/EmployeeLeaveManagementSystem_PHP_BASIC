<?php
session_start();

$emp_id = $_POST['emp_id'];
$emp_password = $_POST['emp_password'];


$conn = mysqli_connect('localhost', 'root', '', 'ELMS');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "select emp_password from faculty where emp_id = '$emp_id'";


$result = mysqli_query($conn, $sql);
$log=mysqli_fetch_assoc($result);

if ($log==$emp_password) {
    
   
		 
		 header('Location: faculty_home.php');
		
    }
} else {
   header('Location: admin_error.php');
}




/*
if (mysqli_query($conn, $sql)) {
    header('Location: student.php');

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
*/



mysqli_close($conn);












?>
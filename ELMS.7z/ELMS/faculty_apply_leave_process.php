<?php
session_start();
$emp_id = $_POST['emp_id'];
$leave_type = $_POST['leave_type'];
$from_date = $_POST['from_date'];
$to_date = $_POST['to_date'];
$leave_description = $_POST['leave_description'];




$leave_id = $_SESSION["emp_id"];

$conn = mysqli_connect('localhost', 'root', '', 'elms');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


$sql = "INSERT INTO faculty_leave ( emp_id, leave_type, from_date ,to_date, leave_description) VALUES ('$emp_id', '$leave_type','$from_date','$to_date','$leave_description')";


if (mysqli_query($conn, $sql)) {
 echo "New record created successfully";
	header('Location:faculty_apply_leave_confirm.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);

?>
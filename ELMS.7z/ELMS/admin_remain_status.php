<?php
session_start();

$con=mysqli_connect('localhost','root','','elms');
// Check connection

 
?>

<html>
	<head>
		<title>ELMS-emp</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1><a href="index.html"><img src= "C:\xampp\htdocs\ELMS\images\main_logo.png" width="150" height="40"> </img></a></h1>
					<nav id="nav">
						<ul>
							<li><a href="index.html">Home</a></li>
							
							<li><a href="admin_add_faculty.html">Add Another Faculty</a></li>
							<li><a href="emp_home.php" >emp Home</a></li>
							<li><a href="logout_process_emp.php" >Logout</a></li>
							
						</ul>
					</nav>
					
					
			
		
					
									</header>


				</div>
			<!-- Main -->
				<section id="main" class="container">
					<header>
						
    
	<?php
			
	
$sql="SELECT * from faculty_leave";

$result=mysqli_query($con,$sql) ;

  // Fetch one and one row
  echo "<table border ='1px'>";
  
  echo  "<tr>";
  echo "<th><u><b>emp_id</b></u></th>";
  echo "<th><u><b>leave type</b></u></th>";
  echo "<b><u><th>from date</b></u></th>";
  echo "<b><u><th>to date</b></u></th>";
  echo "<b><u><th>leave description</b></u></th>";
  echo "<b><u><th>status approve</b></u></th>";
  echo "<b><u><th>status reject</b></u></th>";
  echo  "</tr>";
  while ($row=mysqli_fetch_array($result))
  {
	echo  "<tr>";
	
	echo  "<td>" .$row['emp_id'] . "</td>";
	echo  "<td>" .$row['leave_type'] . "</td>";
	echo  "<td>" .$row['from_date'] . "</td>" ;
	echo  "<td>" .$row['to_date'] . "</td>" ;
	echo  "<td>" .$row['leave_description'] . "</td>" ;
	echo "<td>" .'<a href="admin_status_approve.php">approve</a>' ."</td>"; 
	echo "<td>" .'<a href="admin_status_reject.php">reject</a>' ."</td>";
	
	echo  "</tr>";
	
	}
	
	echo"</table>";
				?>
						
					</header>
					
	

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
						<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
						<li><a href="#" class="icon fa-google-plus"><span class="label">Google+</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

				
	
				
				
				
				
	</body>
</html>
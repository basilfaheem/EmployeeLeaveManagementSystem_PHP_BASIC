<?php
   $db = mysqli_connect('localhost', 'root', '', 'ELMS');
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
          
      $myusername =mysqli_real_escape_string($db,$_POST['username']);
      $mypassword =mysqli_real_escape_string($db,$_POST['password']); 
      echo $myusername;
      $sql = "SELECT emp_id FROM faculty WHERE emp_id = '$myusername' and emp_password = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) {
         session_register("myusername");
         $_SESSION['login_user'] = $myusername;
         
         header("location: index.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>

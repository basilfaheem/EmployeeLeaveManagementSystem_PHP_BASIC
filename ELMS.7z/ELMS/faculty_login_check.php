<?php
session_start();


$emp_id = $_POST['emp_id'];
$emp_password = $_POST['emp_password'];

$_SESSION['emp_id'] = $emp_id;


$conn = mysqli_connect('localhost', 'root', '', 'ELMS');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "select * from faculty where emp_id = '$emp_id' and emp_password = '$emp_password'";


$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
       
		
		$_SESSION["emp_id"] = $row["emp_id"];
		
		
		 
		 
		 echo $_SESSION["emp_id"];
		 header('Location: faculty_home.php');
		
    }
} else {
   header('Location: admin_error.php');
}




/*
if (mysqli_query($conn, $sql)) {
    header('Location: student.php');

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
*/



mysqli_close($conn);












?>
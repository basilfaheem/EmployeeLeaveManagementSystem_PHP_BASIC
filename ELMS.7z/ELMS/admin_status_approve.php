<?php
session_start();

$admin_id = $_SESSION['admin_id'];
$emp_id = $_GET['emp_id'];

if(!$_SESSION["admin_id"])
{
header('Location: faculty_error.php');	
}
else
{
											
	$conn = mysqli_connect('localhost', 'root', '', 'elms');
	if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
				}
					
$sql = "update faculty_leave set status = 1 ";
	

	
	
	$result = mysqli_query($conn, $sql);
	header('Location:admin_final_status_approved.php');	
	

														

												

}

?>
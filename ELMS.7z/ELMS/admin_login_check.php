<?php
session_start();

$admin_id = $_POST['admin_id'];
$password = $_POST['password'];
$_SESSION['admin_id'] = $admin_id;

$conn = mysqli_connect('localhost', 'root', '', 'ELMS');
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "select * from admin where admin_id = '$admin_id' and password = '$password'";


$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
       
		
		$_SESSION["admin_id"] = $row["admin_id"];
		
		 header('Location: admin_home.php');
		
    }
} else {
   header('Location: error.html');
}




/*
if (mysqli_query($conn, $sql)) {
    header('Location: student.php');

} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
*/



mysqli_close($conn);












?>
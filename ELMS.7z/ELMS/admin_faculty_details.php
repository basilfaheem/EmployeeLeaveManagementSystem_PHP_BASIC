
<html>
	<head>
	
		<title>ELMS</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body class="landing">
		<div id="page-wrapper">
<div id="page-wrapper">
			<!-- Header -->
				<header id="header" >
					<h1><a href="index.html">ELMS</a></h1>
					<nav id="nav">
						<ul>
							<li><a href="admin_home.php">Home</a></li>					
							
							<li><a href="logout_process_admin.php" >Logout</a></li>
						</ul>
					</nav>
				</header>
	</div>						
			<!-- Banner -->
				<section id="main" class="container">
					<header>
						<h2>Faculty Details!</h2>
						
					</header>





<section class="box">
									<center><h2>Major Projects</h2></center>

									
									<div class="table-wrapper">
										<table>
											<thead>
												<tr><b>
													<th>Emp ID</th>
													<th>Emp Name</th>
													<th>Emp Dept</th>
													<th>Emp DOJ</th>	
													<th>Emp Mobile</th>
													<th>Emp Email ID</th>
													<th>Emp DOB</th>
													<th>Emp BG</th>													
												</b></tr>
											</thead>
											<tbody>
											
											
											<?php
											
												$conn = mysqli_connect('localhost', 'root', '', 'elms');
												if (!$conn) {
													die("Connection failed: " . mysqli_connect_error());
												}
							
											
												$sql = "select * from faculty ";


												$result = mysqli_query($conn, $sql);

												if (mysqli_num_rows($result) > 0) {
													// output data of each row
													while($row = mysqli_fetch_assoc($result)) {
													   
														
														echo "<tr><td>";
														echo $row["emp_id"];
														echo "</td><td>";
														echo $row["emp_name"];
														echo "</td><td>"; 
														echo $row["emp_dept"];
														echo "</td><td>"; 
														echo $row["emp_DOJ"];
														echo "</td><td>"; 
														echo $row["emp_mobile_no"];
														echo "</td><td>"; 
														echo $row["emp_email"];
														echo "</td><td>"; 
														echo $row["emp_DOB"];
														echo "</td><td>"; 
														echo $row["emp_BG"];
														echo "</td></tr>";		
														 
														 
														
													}
												}

											
											
											
											
											
											
											?>
											
											
											
											
											
											
											
											
											
											
											
												
												
											</tbody>
											
										</table>
									</div>

									

			<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
						<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
						<li><a href="#" class="icon fa-google-plus"><span class="label">Google+</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

		</div>

		






											
												
											</body>
											
										</table>
									</div>
									
									<?php echo $row['emp_name']; ?>
									
									<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
									

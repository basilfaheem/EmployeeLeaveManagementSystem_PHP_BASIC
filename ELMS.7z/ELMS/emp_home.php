<?php
session_start();

$emp_id = $_SESSION["emp_id"];
$emp_name = $_SESSION["emp_name"];


if(!$_SESSION["emp_id"])
{
header('Location: faculty_error.php');	
}
else
{
	

?>


<!DOCTYPE HTML>

<html>
	<head>
		<title>ELMS-faculty</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<body>
		<div id="page-wrapper">

			<!-- Header -->
				<header id="header">
					<h1><a href="index.html"><img src= "C:\xampp\htdocs\ELMS\images\main_logo.png" width="150" height="40"> </img></a></h1>
					<nav id="nav">
						<ul>
							<li><a href="faculty_home.php">Home</a></li>
							<li><a href="faculty_allote.php">Alloted</a></li>

							<li>
								<a href="#" class="icon fa-angle-down">Status</a>
								<ul>
									    
								    <li><a href="faculty_status_approved.php">Approved</a></li>
									<li><a href="faculty_status_rejected.php">Rejected</a></li>
									<li><a href="faculty_status_holded.php">Holded</a></li>
									
								</ul>
							</li>
							<li>
							<a href="#" class="icon fa-angle-down">Projects</a>
							<ul>
									<li><a href="faculty_projects_mini.php">Mini</a></li>
									<li><a href="faculty_projects_major.php">Major</a></li>
									
								</ul>
							
							</li>
							
							<li><a href="logout_process_faculty.php" class="button">LogOut</a></li>
						</ul>
					</nav>
				</header>
</div>
			<!-- Main -->
				<section id="main" class="container">
					<header>
						<h2>Welcome <?php echo $emp_name; ?> </h2>
						
					</header>
									
<header>

</header>
					
							
	

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrollgress.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="assets/js/main.js"></script>
<!-- Footer -->
				<footer id="footer">
					<ul class="icons">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
						<li><a href="#" class="icon fa-dribbble"><span class="label">Dribbble</span></a></li>
						<li><a href="#" class="icon fa-google-plus"><span class="label">Google+</span></a></li>
					</ul>
					<ul class="copyright">
						<li>&copy; Untitled. All rights reserved.</li><li>Design: <a href="http://html5up.net">HTML5 UP</a></li>
					</ul>
				</footer>

	</body>
</html>
<?php
}

?>